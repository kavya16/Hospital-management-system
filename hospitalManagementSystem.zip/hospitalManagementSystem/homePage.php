<?php
require_once "./components/PDO/pdo.php";
error_reporting(0);
session_start();
session_destroy();

if($_SESSION['message']) {
    $message = $_SESSION['message'];

    echo "<script type='text/javascript'>
    alert('$message')
    </script>";
}
$sql = "SELECT * FROM doctors";

$sqlrows = $pdo->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Management System</title>
    <link rel="icon" type="image/x-icon" href="./assets/images/logo/hospital_logo.png">
    <link rel="stylesheet" type="text/css" href="style.css">
    <?php
    include './bootstrap/bootstrap.php';
    ?>
</head>
<body>
    <nav>
       <a href=""><img class="logo" alt="Hospital$" src="./assets/images/logo/hospital_logo.png" width="70px" height="70px"/></a>

        <ul>
            <li><a href="">Home</a></li>
            <li><a href="">Contact</a></li>
            <li><a href="">Appointment</a></li>
            <li><a href="./components/login/login.php" class="btn btn-success">Login</a></li>
        </ul>
    </nav>

    <div class="section1">
    <label class="img_txt">We care your health</label>
        <img class="main_img" src="./assets/images/hospital/hospital_image1.webp" />
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <img class="welcome_img" src="./assets/images/hospital/hospital_image2.jpeg" />  
            </div>
            <div class="col-md-8">
                <h1>About our hospital</h1>
                <p>
                A hospital is a health care institution providing patient treatment with specialized health science and auxiliary healthcare staff and medical equipment. 
                The best-known type of hospital is the general hospital, which typically has an emergency department to treat urgent health problems ranging from fire and accident victims to a sudden illness. 
                A district hospital typically is the major health care facility in its region, with many beds for intensive care and additional beds for patients who need long-term care. 
                Specialized hospitals include trauma centers, rehabilitation hospitals, children's hospitals, seniors' (geriatric) hospitals, and hospitals for dealing with specific medical needs such as psychiatric treatment (see psychiatric hospital) and certain disease categories. 
                </p>
            </div>
        </div>
    </div>

    <center>
    <h1>Our Doctors</h1>
</center>

<div class="container">
    <div class="row">

    <?php
    //we cannot write the php code inside the html so have to divide based on php code 
    while($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        $imgUrl = $rows['image'];
    ?>
        <div class="col-md-4">
            <img class="doctor" 
            src= <?php
            echo "'./assets/images/$imgUrl'";
            ?>
            width="350px" height="500px"/>
            <h3>
                <?php
                $fullName = $rows['firstName'] . ' ' . $rows['middleName'] . ' ' . $rows['lastName'];
                echo "Dr. {$fullName}";
                ?>
            </h3>
            <p>
            <?php
                $description = $rows['Description'];
                echo "$description";
            ?>
            </p>
        </div>

    <?php
    }
    ?>
</div>
</div>

<center>
<h1>Treatments</h1>
</center>

<div class="container">
    <div class="row">

    <?php
    //we cannot write the php code inside the html so have to divide based on php code 
    $sql2 = "SELECT * FROM department";
    $sqlrows2 = $pdo->query($sql2);

    while($rows = $sqlrows2->fetch(PDO::FETCH_ASSOC)) {
        $imgUrl = $rows['departmentImage'];
    ?>
        <div class="col-md-4">
            <img class="treatment" 
            src= <?php
            echo "'./assets/images/department/$imgUrl'";
            ?>
            width="350px" height="500px"/>
            <h3>
                <?php
                $DepartmentName = $rows['DepartmentName'];
                echo "{$DepartmentName}";
                ?>
            </h3>
            <p>
            <?php
                $description = $rows['DepartmentDescription'];
                echo "$description";
            ?>
            </p>
        </div>

    <?php
    }
    ?>
      
</div>
</div>

<footer>
    <h2 class="footer_text">I have to add footer related information here overviewing some webpages</h2>
</footer>
</body>
</html>