<?php
//first we need to connect to the database 

$pdo = new PDO('mysql:host=localhost;port=8889;dbname=hospital',
'admin', 'Admin@1996');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>