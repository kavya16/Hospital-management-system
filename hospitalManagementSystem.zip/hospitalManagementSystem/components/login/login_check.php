<?php
require_once "../PDO/pdo.php";
session_start();
if($_SERVER["REQUEST_METHOD"] == "POST") {
    $userName = $_POST['username'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM login WHERE userName='".$userName."' AND password='".$password."' ";
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $loginId = $row['loginId'];
    if($row["userType"] == "admin"){
       $_SESSION['username'] = $userName;
       $_SESSION['userType'] = 'admin';
       $_SESSION['loginId'] = $loginId;
       header("location:../users/admin/adminhome.php"); //redirecting to particular page
     }elseif($row["userType"] == "patient"){
         $_SESSION['username'] = $userName;
         $_SESSION['userType'] = 'patient';
         $_SESSION['loginId'] = $loginId;
         header("location:../users/patient/patienthome.php");
     }elseif($row['userType'] == "doctor"){
        $_SESSION['username'] = $userName;
        $_SESSION['userType'] = 'doctor';
        $_SESSION['loginId'] = $loginId;
        header("location:../users/doctor/doctorhome.php");
     }else {
         $message = "username or password do not match";
         $_SESSION['loginMessage'] = $message; //we are storing this message and sending this one to the login.php
         header("location:login.php");
     }
}
?>