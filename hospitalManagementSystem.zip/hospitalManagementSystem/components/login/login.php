<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" type="text/css" href="loginStyle.css" />
    <?php
    include '../../bootstrap/bootstrap.php';
    ?>
</head>
<body class="body">
    <center>
        <div class="form_deg">
            <center class="title_deg">
                Login Form
                <h4>
                    <?php
                    error_reporting(0);
                    session_start();
                    echo $_SESSION['loginMessage'];
                    session_destroy();
                    ?>
                </h4>
            </center>
            <form action="login_check.php" method="post" class="login_form">
                <div>
                <label class="label_deg">Username</label>
                <input type="text" name="username" />
                </div>

                <div>
                <label class="label_deg">Password</label>
                <input type="password" name="password" />
                </div>

                <div>
                    <input class="btn btn-primary" type="submit" name="submit" value="login" />
                </div>
            </form>
        </div>
    </center>
</body>
</html>