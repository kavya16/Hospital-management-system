<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}

if($_GET['departmentName']){
    $departmentName = $_GET['departmentName'];
    $sql = "SELECT * FROM department WHERE DepartmentName = '$departmentName'";
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}

//update_department.php?departmentName={$row["DepartmentName"]}

if(isset($_POST['Update'])) {
    $departmentName = $_POST['departmentName'];
    $chiefName = $_POST['chiefName'];
    $description = $_POST['description'];

    $array = array(); //this checking of username existance can be done using jquery
    $sql = "SELECT * FROM department WHERE DepartmentName = '$departmentName'";
    $sqlrows = $pdo->query($sql);
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }
    if(count($array) == 1) {
        $sql = "UPDATE `department` SET `DepartmentName` = '$departmentName', 
        `DepartmentDescription` = '$description',
        `HeadName` = '$chiefName'
         WHERE `department`.`DepartmentName` = '$departmentName'";

    $stmt = $pdo->query($sql);
    if($stmt){
        header("location:view_department.php");
    }else {
            echo "<p style='color:red;'>Update Failed</p>";
            header("location:#");
    }
    
    }else {
    echo "<script type='text/javascript'>
          alert('Doctor doesn't exist. Please create the doctor');
          </script>";
          header("location:view_doctor.php");
    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>

    <?php
    include 'admin_sidebar.php';
    ?>

    <center>
    <div class="content">
    <h1>Update Department</h1>

<div class="div_deg">

<form action="#" method="POST" class="form"> <!--# means the handle code will be in the same file-->
   
          
  <div class="addinput">
    <label class="label_text" for="departmentName">Department Name</label>
    <input  style = "margin: 5px;" class="inputField" id ="departmentName" type="text" name="departmentName" value="<?php echo "{$row['DepartmentName']}";?>"/>
   </div> 

   <div style="margin-left: -355px; margin-top: 10px;">
   <label for="chief" style="font-weight: 700;">Choose Chief of the Department: </label>
   <select name="chiefName" id="chief" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT firstName, middleName, lastName, email FROM doctors WHERE level = 'Chief'";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $fullName = $array2[$i]["firstName"] . " " . $array2[$i]["middleName"] . " " . $array2[$i]["lastName"];
    if($row['HeadName'] == $fullName) {
        echo "<option value='$fullName' selected>$fullName</option>";
    }else {
        echo "<option value='$fullName'>$fullName</option>";
    }
    $i++;
    }
   ?>
    </select>
</div>

   <div class="addinput">
    <label class="label_text">About Department</label>
    <textarea class="input_txt" name="description"><?php echo "{$row['DepartmentDescription']}";?></textarea>
   </div> 

   <div class="addinput button">
    <input class="btn btn-primary" id="submit" type="submit" name="Update" value="Update" />
   </div>
</form>
</div>

</center>
</body>
</html>