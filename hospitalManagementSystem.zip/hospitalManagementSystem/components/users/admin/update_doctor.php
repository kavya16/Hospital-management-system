<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}

if($_GET['loginId']){
    $user_id = $_GET['loginId'];
    $sql = "SELECT * FROM doctors WHERE loginId = '$user_id'";
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}

if(isset($_POST['Update'])) {
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $userName = $_POST['userName'];
    $password = $_POST['password'];
    $specialization = $_POST['specialization'];
    $textarea = $_POST['textarea'];
    $level = $_POST['level'];
    $department = $_POST['department'];
    $gender = $_POST['gender'];

    $array = array(); //this checking of username existance can be done using jquery
    $check = "SELECT * FROM doctors WHERE loginId='$user_id'";
    $sqlrows = $pdo->query($check);
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }
    if(count($array) == 1) {
        $sql = "UPDATE `doctors` SET `firstName` = '$firstName', 
        `middleName` = '$middleName', 
        `lastName` = '$lastName', `email` = '$email', `gender` = '$gender',
        `phone` = '$phone', `userName` = '$userName', 
        `password` = '$password', `specialization` = '$specialization', 
        `departmentName` = '$department',
        `level` = '$level', `Description` = '$textarea'
         WHERE `doctors`.`loginId` = $user_id";

    $stmt = $pdo->query($sql);
    if($stmt) {
        $id = $row['loginId'];
        $loginUpdate = false;
        if($row['userName'] != $userName) {
        $sql2 = "UPDATE `login` SET `userName` = '$userName' WHERE loginId = $id";
        $loginUpdate = true;
        }else if($row['phone'] != $phone){
            $sql2 = "UPDATE `login` SET `phone` = '$phone' WHERE loginId = $id";
        $loginUpdate = true;
        }else if($row['email'] != $email) {
            $sql2 = "UPDATE `login` SET `email` = '$email' WHERE loginId = $id";
            $loginUpdate = true;
        }else if($row['password' != $password]) {
            $sql2 = "UPDATE `login` SET `password` = '$password' WHERE loginId = $id";
            $loginUpdate = true;
        }

        if($loginUpdate) {
            $finalUpdate = $pdo->query($sql2);
        }
        $visible = true;

    } 
    if($visible){
        header("location:view_doctor.php");
        }else {
            echo "<p style='color:red;'>Update Failed</p>";
            header("location:#");
        }
    }else {
    echo "<script type='text/javascript'>
          alert('Doctor doesn't exist. Please create the doctor');
          </script>";
          header("location:add_doctor.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>

    <?php
    include 'admin_sidebar.php';
    ?>

    <center>
    <div class="content">
    <h1 style="margin-left: 90px;">Update Doctor</h1>
    <div class="div_deg">

<form action="#" method="POST" class="form"> <!--# means the handle code will be in the same file-->
   
  <div class="addinput">
    <label class="label_text" for="firstName">First Name</label>
    <input  style = "margin: 5px;" class="inputField" id ="firstName" 
    type="text" name="firstName" value="<?php echo "{$row['firstName']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="middleName">Middle Name</label>
    <input  style = "margin: 5px;" class="inputField" id="middleName" type="text" name="middleName" value="<?php echo "{$row['middleName']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="lastName">Last Name</label>
    <input  style = "margin: 5px;" class="inputField" id="lastName" type="text" name="lastName" value="<?php echo "{$row['lastName']}";?>"/>
   </div> 

   <strong style="margin-left: -190px;">Gender</strong>
 <div>
  <input type="radio" id="male" class="level" name="gender" value="Male" style="margin-left: -190px;" 
  <?php
  if($row['gender'] == 'Male') {
    echo "selected";
  }
  ?>
  >
  <label for="male">Male</label><br>
  <input type="radio" id="female" class="level" name="gender" value="Female" style="margin-left: -173px;"
  <?php
  if($row['gender'] == 'Female') {
    echo "selected";
  }
  ?>
  >
  <label for="female">Female</label><br>
 </div> 

   <div class="addinput">
    <label class="label_text" for="email">Email</label>
    <input  style = "margin: 5px;" class="inputField" id="email" type="email" name="email" value="<?php echo "{$row['email']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="phone">Phone</label>
    <input  style = "margin: 5px;" class="inputField" id="phone" type="number" name="phone" value="<?php echo "{$row['phone']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="userName">username</label>
    <input  style = "margin: 5px;" class="inputField" id ="userName" type="text" name="userName" value="<?php echo "{$row['userName']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="password">password</label>
    <input  style = "margin: 5px;" class="inputField" id ="password" type="text" name="password" value="<?php echo "{$row['password']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="specialization">Specialization</label>
    <input  style = "margin: 5px;" class="inputField" id ="specialization" type="text" name="specialization" value="<?php echo "{$row['specialization']}";?>"/>
   </div> 

   <div style="margin-left: -245px; margin-top: 10px;">
   <label for="department" style="font-weight: 700;">Department </label>
   <select name="department" id="department" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT DepartmentName FROM department";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $departmentName = $array2[$i]["DepartmentName"];
    if($row['departmentName'] == $departmentName) {
        echo "<option value='$departmentName' selected>$departmentName</option>";
    }else {
        echo "<option value='$departmentName'>$departmentName</option>";
    }
    $i++;
    }
   ?>
    </select>
</div>

<strong style="margin-left: -110px;">Level of the Doctor</strong>
 <div>
  <input type="radio" id="chief" class="level" name="level" value="Chief" style="margin-left: -190px;">
  <label for="chief">Chief</label><br>
  <input type="radio" id="senior" class="level" name="level" value="Senior" style="margin-left: -185px;">
  <label for="senior">Senior</label><br>
  <input type="radio" id="junior" class="level" name="level" value="Junior" style="margin-left: -185px;">
  <label for="junior">Junior</label><br>
  <input type="radio" id="intern" class="level" name="level" value="Intern" style="margin-left: -185px;">
  <label for="intern">Intern</label><br>
 </div> 

   <div class="addinput">
    <label class="label_text">Description</label>
    <textarea class="input_txt" name="textarea"><?php echo "{$row['Description']}";?></textarea>
   </div> 

   <div class="addinput button">
    <input class="btn btn-primary" id="submit" type="submit" name="Update" value="Update" />
   </div>

</form>
</div>

</center>
</body>
</html>