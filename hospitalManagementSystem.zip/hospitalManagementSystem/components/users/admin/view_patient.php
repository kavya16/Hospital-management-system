<?php
require_once "../../PDO/pdo.php";

//sql connection and query is here
$sql = "SELECT * FROM patientadmissions";
$stmt = $pdo->query($sql);
error_reporting(0);

session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}
$user_type = 'patient';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>
    <?php
    include 'admin_sidebar.php';
    ?>
    <div class="content">
        <center>
        <h1>Patient Details</h1>
        <?php
        if($_SESSION['message']){
            $message = $_SESSION['message'];
            echo "<center><p style='color: green;'>$message</p></center>";
        }
        unset($_SESSION['message']);
        ?>
        <div class="innerContent">
        <table border="1px">
        <thead>
            <tr>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Full Name</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Gender</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Email</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Phone</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">User Name</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Password</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Health Problem</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Doctor</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Department Name</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Delete</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Update</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            ?>
            <tr>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["firstName"].' '.$row["middleName"].' '.$row["lastName"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["gender"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["email"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["phone"]}"
            ?>
            </td> 

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["username"]}"
            ?>
            </td> 

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["password"]}"
            ?>
            </td> 

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["healthProblem"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["doctor"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["departmentName"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "<a onClick=\"javaScript: return confirm('Are You sure to Deletethis');\"
             href='delete.php?loginId={$row["loginId"]}&patient_id={$row["patientId"]}&user_type={$user_type}' class='btn btn-danger'>Delete</a>";
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "<a class='btn btn-primary' href='update_patient.php?loginId={$row["loginId"]}&user_type={$user_type}'>Update</a>";
            ?>
            </td>
            
            </tr>
            <?php
            }
            ?>  
        </tbody>          
        </table>
        </div>
        </center>
    </div>
</body>
</html>