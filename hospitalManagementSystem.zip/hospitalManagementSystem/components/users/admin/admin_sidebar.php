
<?php
session_start();
require_once "../../PDO/pdo.php";
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}
?>

    <header class="header">
        <a href="adminhome.php">Admin Dashboard</a>
        <div class="logout">
        <a href="../../login/logout.php" class="btn btn-primary">Logout</a>
        </div>
    </header>

    <aside style="position: relative;">
        <ul>
            <li>
                <a href="add_patient.php">Add Patient</a>
            </li>
            <li>
                <a href="view_patient.php">View Patient</a>
            </li>
            <li>
                <a href="add_doctor.php">Add Doctor</a>
            </li>
            <li>
                <a href="view_doctor.php">View Doctor</a>
            </li>
            <li>
                <a href="add_department.php">Add Department</a>
            </li>
            <li>
                <a href="view_department.php">View Department</a>
            </li>
            <li>
                <a href="add_treatment.php">Add Treatment</a>
            </li>
            <li>
                <a href="view_treatment.php">View Treatments</a>
            </li>
            <li>
                <a href="add_slot.php">Add Slot</a>
            </li>
            <li>
                <a href="view_slot.php">View Slot</a>
            </li>
        </ul>
    </aside>
