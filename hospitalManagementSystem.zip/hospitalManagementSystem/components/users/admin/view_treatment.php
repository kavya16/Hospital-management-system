<?php
require_once "../../PDO/pdo.php";

//sql connection and query is here
$sql = "SELECT * FROM treatment";
$stmt = $pdo->query($sql);
error_reporting(0);

session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>
    <?php
    include 'admin_sidebar.php';
    ?>
    <div class="content">
        <center>
        <h1 style="margin-left: -100px;">Treatment Details</h1>
        <?php
        if($_SESSION['message']){
            $message = $_SESSION['message'];
            echo "<center><p style='color: green;'>$message</p></center>";
        }
        unset($_SESSION['message']);
        ?>
        <div class="innerContent">
        <table border="1px">
        <thead>
            <tr>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Treatment Name</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Category</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Price</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Department</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Treatment Description</th>                                
                <th style="padding: 20px; font-size: 15px; text-align: center;">Delete</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Update</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            ?>
            <tr>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["treatmentName"];
            ?>
            </td>


            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["category"];
            ?>
            </td>


            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["price"];
            ?>
            </td>


            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["Department"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["TreatmentDescription"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "<a onClick=\"javaScript: return confirm('Are You sure to Deletethis');\"
             href='delete.php?treatmentName={$row["treatmentName"]}' class='btn btn-danger'>Delete</a>";
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "<a class='btn btn-primary' href='update_treatment.php?specialId={$row["specialId"]}'>Update</a>";
            ?>
            </td>
            
            </tr>
            <?php
            }
            ?>  
        </tbody>          
        </table>
        </div>
        </center>
    </div>
</body>
</html>
