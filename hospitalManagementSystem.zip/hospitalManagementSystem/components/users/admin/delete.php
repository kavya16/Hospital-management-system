<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}

$baseDestination = "/Applications/MAMP/htdocs/hospitalManagementSystem/assets/images/";

if($_GET['loginId']) {
    $id = $_GET['loginId'];
    $sql = "DELETE FROM login WHERE loginId = $id";
    $stmt = $pdo->query($sql);
if($stmt){
if($_GET['user_type'] == 'patient') {
    $sql = "DELETE FROM patientadmissions WHERE loginId = $id";
    $stmt = $pdo->query($sql);
    if($stmt) {
    $_SESSION['message'] = 'Delete patient is successful';
    }
    header("location:view_patient.php");

}else if($_GET['user_type'] == 'doctor') {
        $sql = "DELETE FROM doctors WHERE loginId = $id";
        $stmt = $pdo->query($sql);
        if($stmt) {
            $deleteFile = $baseDestination.$_GET['user_image'];
            unlink("$deleteFile");
            $_SESSION['message'] = 'Delete doctor and the assets associated are successful';
        }
        header("location:view_doctor.php");
    }
}
}else if($_GET['departmentName']) {
    $departmentName = $_GET['departmentName'];
    $sql = "DELETE FROM department WHERE DepartmentName = '$departmentName'";
    $stmt = $pdo->query($sql);
    if($stmt) {
       $deleteFile = $baseDestination.$_GET['departmentImage'];
       unlink("$deleteFile");
       $_SESSION['message'] = 'Delete department and the assets associated are successful';
    }
    header("location:view_department.php"); 
}else if($_GET['treatmentName']) {
    $treatmentName = $_GET['treatmentName'];
    $sql = "DELETE FROM treatment WHERE treatmentName = '$treatmentName'";
    $stmt = $pdo->query($sql);
    $_SESSION['message'] = 'Delete treatment and the assets associated are successful';
    header("location:view_treatment.php"); 
}
?>