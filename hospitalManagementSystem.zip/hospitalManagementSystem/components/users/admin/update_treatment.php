<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}

if($_GET['specialId']){
    $specialId = $_GET['specialId'];
    $sql = "SELECT * FROM treatment WHERE specialId = '$specialId'";
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
}

if(isset($_POST['Update'])) {
    $treatmentName = $_POST['treatmentName'];
    $category = $_POST['category'];
    $treatmentDescription = $_POST['description'];
    $price = $_POST["price"];
    $department = $_POST["department"];
    $array = array(); //this checking of username existance can be done using jquery
    $sql = "SELECT * FROM treatment WHERE specialId = '$specialId'";
    $sqlrows = $pdo->query($sql);
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }
    if(count($array) == 1) {
        $sql = "UPDATE `treatment` SET `category` = '$category', `treatmentName` = '$treatmentName', 
        `TreatmentDescription` = '$treatmentDescription', `price` = '$price', `Department` = '$department'
         WHERE `treatment`.`specialId` = '$specialId'";

    $stmt = $pdo->query($sql);
    echo "reached";
        $visible = true;
    }else {
    echo "<script type='text/javascript'>
          alert('Doctor doesn't exist. Please create the doctor');
          </script>";
          header("location:add_treatment.php");
    }
    if($visible){
        header("location:view_treatment.php");
    }else {
            echo "<p style='color:red;'>Update Failed</p>";
            header("location:#");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>

    <?php
    include 'admin_sidebar.php';
    ?>

    <center>
    <div class="content">
    <h1>Update Treatment</h1>

<div class="div_deg">

<form action="#" method="POST" class="form"> <!--# means the handle code will be in the same file-->
   
          
  <div class="addinput">
    <label class="label_text" for="treatmentName">Treatment Name</label>
    <input  style = "margin: 5px;" class="inputField" id ="treatmentName" type="text" name="treatmentName" value="<?php echo "{$row['treatmentName']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="category">Category</label>
    <input  style = "margin: 5px;" class="inputField" id ="category" type="text" name="category" value="<?php echo "{$row['category']}";?>"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="price">price</label>
    <input  style = "margin: 5px;" class="inputField" id ="price" type="number" name="price" value="<?php echo "{$row['price']}";?>"/>
   </div> 

   <div style="margin-left: -245px; margin-top: 10px;">
   <label for="department" style="font-weight: 700;">Department </label>
   <select name="department" id="department" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT DepartmentName FROM department";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $departmentName = $array2[$i]["DepartmentName"];
    echo "<option value='$departmentName'>$departmentName</option>";
    $i++;
    }
   ?>
    </select>
</div>

   <div class="addinput">
    <label class="label_text">Treatment Description</label>
    <textarea class="input_txt" name="description"><?php echo "{$row['TreatmentDescription']}";?></textarea>
   </div> 

   <div class="addinput button">
    <input class="btn btn-primary" id="submit" type="submit" name="Update" value="Update" />
   </div>
</form>
</div>

</center>
</body>
</html>