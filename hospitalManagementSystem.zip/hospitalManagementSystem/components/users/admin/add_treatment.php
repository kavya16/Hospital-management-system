<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}



if(isset($_POST['addTreatment'])) {
    $treatmentName = $_POST['treatmentName'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $department = $_POST['department'];
    $description = $_POST['textarea'];
    $check = "SELECT * FROM treatment WHERE treatmentName='$treatmentName'";
    $sqlrows = $pdo->query($check);
    $array = array(); //this checking of username existance can be done using jquery
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }

    if(count($array) == 0) {
        $sql = "INSERT INTO 
        treatment(category, treatmentName, Description, price, Department)
         VALUES ('$category','$treatmentName','$description','$price','$department')";
        $stmt = $pdo->query($sql);
        echo "reached1";
        if($stmt) {
            $check = "SELECT * FROM treatment WHERE treatmentName='$treatmentName'";
            $sqlrows = $pdo->query($check);
            $array = array(); //this checking of username existance can be done using jquery
            while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
                array_push($array, $rows);
            }

            print_r($array);
            //header("location: add_treatment.php");
        }else {
            echo "Upload failed";
            echo "<script type='text/javascript'>
            alert('Please try again');
            </script>";
        }
    }else {
    echo "<script type='text/javascript'>
          alert('$treatmentName already exist. Try another one');
          </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>

    <?php
    include 'admin_sidebar.php';
    ?>

<div class="content">
<p></p>
<center>
<h1 style="margin-left: 70px">Add Treatment</h1>

<div class="div_deg">
<form action="#" method="POST" class="form" enctype="multipart/form-data"><!--# means the handle code will be in the same file-->

  <div class="addinput">
    <label class="label_text" for="treatmentName">Treatment Name</label>
    <input  style = "margin: 5px;" class="inputField" id="treatmentName" type="text" name="treatmentName" placeholder="Bipas"/>
   </div> 

    <div class="addinput">
    <label class="label_text" for="category">Category</label>
    <input  style = "margin: 5px;" class="inputField" id ="category" type="text" name="category" placeholder="checkup"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="price">Price</label>
    <input  style = "margin: 5px;" class="inputField" id="price" type="number" name="price" placeholder="1_00_000"/>
   </div> 

   <div style="margin-left: -245px; margin-top: 10px;">
   <label for="department" style="font-weight: 700;">Department </label>
   <select name="department" id="department" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT DepartmentName FROM department";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $departmentName = $array2[$i]["DepartmentName"];
    echo "<option value='$departmentName'>$departmentName</option>";
    $i++;
    }
   ?>
    </select>
</div>

   <div class="addinput">
    <label class="label_text">Treatment Description</label>
    <textarea class="input_txt" name="textarea" placeholder="About that procedure...."></textarea>
   </div> 

   <div class="addinput button">
    <input class="btn btn-primary" id="submit" type="submit" name="addTreatment" value="Add" />
   </div>

</form>
</div>
</center>
</div>
</body>
</html>