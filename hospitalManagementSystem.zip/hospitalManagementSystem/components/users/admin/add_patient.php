<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}

if(isset($_POST['add_patient'])) {
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $userName = $_POST['userName'];
    $password = $_POST['password'];
    $textarea = $_POST['textarea'];
    $department = $_POST['department'];
    $doctorName = $_POST['doctor'];
    $gender = $_POST['gender'];
    $array = array(); //this checking of username existance can be done using jquery
    $check = "SELECT * FROM login WHERE userName='$userName'";
    $sqlrows = $pdo->query($check);
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }

    if(count($array) == 0) {
    $sql = "INSERT INTO 
    login(userName, phone, email, userType, password) VALUES ( '$userName', '$phone', '$email', 'patient', '$password')";
    $stmt = $pdo->query($sql);
    $sql2 = "SELECT loginId FROM login WHERE userName = '$userName'";
    $stmt2 = $pdo->query($sql2);
    if($stmt2) {
        $array2 = array();
        while ($rows = $stmt2->fetch(PDO::FETCH_ASSOC)) {
            array_push($array2, $rows);
        }
        $loginid = $array2[0]['loginId'];
        $sql = "INSERT INTO 
        patientadmissions(loginId, firstName, middleName, lastName, gender,
        email, phone, username, password, healthProblem, doctor, departmentName) VALUES ('$loginid', '$firstName', '$middleName',
        '$lastName', '$gender', '$email', '$phone', '$userName', '$password', '$textarea', '$doctorName', '$department')";
    
        $stmt = $pdo->query($sql);
        if($stmt) {
            header("location: add_patient.php");
        }
    }else {
        echo "Upload failed";
    }
    }else {
    echo "<script type='text/javascript'>
          alert('Username already exist. Try another one');
          </script>";
    }
   }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>

    <?php
    include 'admin_sidebar.php';
    ?>

<div class="content">
<p></p>
<center>
<h1 style="margin-left: 90px;">Add Patient</h1>

<div class="div_deg">
<form action="#" method="POST" class="form"> <!--# means the handle code will be in the same file-->
    <div class="addinput">
    <label class="label_text" for="firstName">First Name</label>
    <input  style = "margin: 5px;" class="inputField" id ="firstName" type="text" name="firstName" placeholder="Tanmayee"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="middleName">Middle Name</label>
    <input  style = "margin: 5px;" class="inputField" id="middleName" type="text" name="middleName" placeholder="Swathi"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="lastName">Last Name</label>
    <input  style = "margin: 5px;" class="inputField" id="lastName" type="text" name="lastName" placeholder="Moganti"/>
   </div> 

   <strong style="margin-left: -190px;">Gender</strong>
 <div>
  <input type="radio" id="male" class="male" name="gender" value="Male" style="margin-left: -190px;">
  <label for="male">Male</label><br>
  <input type="radio" id="female" class="female" name="gender" value="Female" style="margin-left: -173px;">
  <label for="female">Female</label><br>
 </div> 

   <div class="addinput">
    <label class="label_text" for="email">Email</label>
    <input  style = "margin: 5px;" class="inputField" id="email" type="email" name="email" placeholder="mogantitanmayeeswathi@gmail.com"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="phone">Phone</label>
    <input  style = "margin: 5px;" class="inputField" id="phone" type="number" name="phone" placeholder="9402712019"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="userName">username</label>
    <input  style = "margin: 5px;" class="inputField" id ="userName" type="text" name="userName" placeholder="tanmayee"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="password">password</label>
    <input  style = "margin: 5px;" class="inputField" id ="password" type="text" name="password" placeholder="password"/>
   </div> 

   <div style="margin-left: -245px; margin-top: 10px;">
   <label for="department" style="font-weight: 700;">Department </label>
   <select name="department" id="department" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT DepartmentName FROM department";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
        $departmentName = $array2[$i]["DepartmentName"];
        echo "<option value='$departmentName'>$departmentName</option>";
    $i++;
    }
   ?>
    </select>
</div>

<div style="margin-left: -100px; margin-top: 10px;">
   <label for="doctor" style="font-weight: 700;">Doctor </label>
   <select name="doctor" id="doctor" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT firstName, middleName, lastName FROM doctors";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $doctorName = $array2[$i]["firstName"] . " " . $array2[$i]["middleName"] . " " . $array2[$i]["lastName"];
    echo "<option value='$doctorName'>$doctorName</option>";
    $i++;
    }
   ?>
    </select>
</div>

   <div class="addinput">
    <label class="label_text">Health Problem</label>
    <textarea class="input_txt" name="textarea" placeholder="About health issue...."></textarea>
   </div> 

   <div class="addinput button">
    <input class="btn btn-primary" id="submit" type="submit" name="add_patient" value="AddPatient" />
   </div>

</form>
</div>
</center>
</div>
</body>
</html>