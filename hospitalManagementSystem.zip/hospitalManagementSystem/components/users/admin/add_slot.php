<?php
require_once "../../PDO/pdo.php";
session_start();
$visible = true;
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'admin') {
    header("location:../../login/login.php"); //redirecting
}

if(isset($_POST['add'])) {
    $slotName = $_POST['slotName'];
    $slotTime = $_POST['slotTime'];
    $department = $_POST['department'];
    $description = $_POST['description'];
    $day = $_POST['day'];
    $slotDate = $_POST['slotDate'];
    $category = $_POST['category'];
    $doctor = $_POST['doctor'];
    $patient = $_POST['patient'];

    $doctorLoginID = substr($doctor, strpos($doctor, "/") + 1);
    $patientLoingID = substr($patient, strpos($patient, "/") + 1);

    $doctorFullName = substr($doctor, 0,strpos($doctor, "/") - 1);
    $patientFullName = substr($patient, 0,strpos($patient, "/") - 1);

    $array = array(); //this checking of department exists existance can be done using jquery
    $check = "SELECT * FROM slots WHERE slotName='$slotName'";
    $sqlrows = $pdo->query($check);
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }
    if(count($array) == 0) {
        $sql = "INSERT INTO `slots`(`slotName`, `category`, `doctorName`, `patientName`, `slotTime`, 
        `day`, `date`, `department`, `slotDescription`, `doctorLoginId`, `patientLoginId`) VALUES 
        ('$slotName', '$category', '$doctorFullName', '$patientFullName','$slotTime', '$day', '$slotDate',
        '$department', '$description', '$doctorLoginID', '$patientLoingID')";
        $stmt = $pdo->query($sql);
        if($stmt) {
           header("location:add_slot.php"); //redirecting  
        }else {
            echo "<script type='text/javascript'>
            alert('Database update failed. Please try again');
            </script>";
        }
    }else {
    echo "<script type='text/javascript'>
          alert('Slot already exist. Try another username');
          </script>";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>

    <?php
    include 'admin_sidebar.php';
    ?>

    <div class="content">
        <center>
        <h1 style="margin-left: 70px;">Add Slot</h1>

    <div>
    <form action="#" method="POST" class="form" enctype="multipart/form-data">
        
    <div class="addinput">
    <label class="label_text" for="slotName">Slot Name</label>
    <input  style = "margin: 5px;" class="inputField" id ="slotName" type="text" name="slotName" placeholder="Blood"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="category">Slot Category</label>
    <input  style = "margin: 5px;" class="inputField" id ="category" type="text" name="category" placeholder="lab"/>
   </div> 


   <div style="margin-left: -135px; margin-top: 10px;">
   <label for="doctor" style="font-weight: 700;">Doctor Name</label>
   <select name="doctor" id="doctor" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT firstName, middleName, lastName , loginId FROM doctors";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $doctorName = $array2[$i]["firstName"] . " " . $array2[$i]["middleName"] . " " . $array2[$i]["lastName"];
    $doctorId = $array2[$i]["loginId"];
    $doctorInfo = $doctorName . '/' . $doctorId;
    echo "<option value='$doctorInfo'>$doctorName</option>";
    $i++;
    }
   ?>
    </select>
</div>  

<div style="margin-left: -135px; margin-top: 10px;">
   <label for="patient" style="font-weight: 700;">Patient Name</label>
   <select name="patient" id="patient" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT firstName, middleName, lastName, loginId FROM patientadmissions";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $patientName = $array2[$i]["firstName"] . " " . $array2[$i]["middleName"] . " " . $array2[$i]["lastName"];
    $patientId = $array2[$i]["loginId"];
    $patientInfo = $patientName . '/' . $patientId;
    echo "<option value='$patientInfo'>$patientName</option>";
    $i++;
    }
   ?>
    </select>
</div>

   <div class="addinput">
    <label class="label_text" for="slotTime">Slot Time</label>
    <input  style = "margin: 5px;" class="inputField" id ="slotTime" type="time" name="slotTime"/>
   </div> 

   <div class="addinput">
    <label class="label_text" for="slotDate">Slot Date</label>
    <input  style = "margin: 5px;" class="inputField" id ="slotDate" type="date" name="slotDate"/>
   </div> 

   <div style="margin-left: -245px; margin-top: 10px;">
   <label for="department" style="font-weight: 700;">Department </label>
   <select name="department" id="department" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT DepartmentName FROM department";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $departmentName = $array2[$i]["DepartmentName"];
    echo "<option value='$departmentName'>$departmentName</option>";
    $i++;
    }
   ?>
    </select>
</div>

<strong style="margin-left: -220px;">Day</strong>
 <div>
  <input type="radio" id="Monday" class="level" name="day" value="Monday" style="margin-left: -190px;" checked>
  <label for="Monday">Monday</label><br>
  <input type="radio" id="Tuesday" class="level" name="day" value="Tuesday" style="margin-left: -185px;">
  <label for="Tuesday">Tuesday</label><br>
  <input type="radio" id="Wednesday" class="level" name="day" value="Wednesday" style="margin-left: -160px;">
  <label for="Wednesday">Wednesday</label><br>
  <input type="radio" id="Thursday" class="level" name="day" value="Thursday" style="margin-left: -175px;">
  <label for="Thursday">Thursday</label><br>
  <input type="radio" id="Friday" class="level" name="day" value="Friday" style="margin-left: -200px;">
  <label for="Friday">Friday</label><br>
  <input type="radio" id="Saturday" class="level" name="day" value="Saturday" style="margin-left: -180px;">
  <label for="Saturday">Saturday</label><br>
  <input type="radio" id="Sunday" class="level" name="day" value="Sunday" style="margin-left: -190px;">
  <label for="Sunday">Sunday</label><br>
 </div> 

   <div class="addinput">
    <label class="label_text">Slot Description</label>
    <textarea class="input_txt" name="description" placeholder="About Slot..."></textarea>
   </div> 

   <div class="addinput button">
    <input class="btn btn-primary" id="submit" type="submit" name="add" value="Add" />
   </div>
</form>
        </div>
        </center>
    </div>
</body>
</html>