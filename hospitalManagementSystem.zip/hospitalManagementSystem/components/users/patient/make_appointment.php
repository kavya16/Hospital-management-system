<?php
require_once "../../PDO/pdo.php";
$user_id = $_SESSION['loginId'];
//sql connection and query is here
$sql = "SELECT * FROM slots WHERE patientLoginId IS NULL";
$stmt = $pdo->query($sql);
error_reporting(0);

session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'patient') {
    header("location:../../login/login.php"); //redirecting
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" type="text/css" href="patient.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>
    <?php
    include 'patient_sidebar.php';
    ?>

    <div class="content">
        <center>
        <h1 style="margin-left: -110px">Slot Details</h1>
        <?php
        if($_SESSION['message']){
            $message = $_SESSION['message'];
            echo "<center><p style='color: green;'>$message</p></center>";
        }
        unset($_SESSION['message']);
        ?>
        <div class="innerContent">
        <table border="1px">
        <thead>
            <tr>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Slot Name</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Doctor Name</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Patient Name</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Category</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Slot Time</th>
                <th style="padding: 20px; font-size: 15px; text-align: center;">Day</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Date</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Department</th>                                
                <th style="padding: 20px; font-size: 15px; text-align: center;">Description</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Doctor Login Id</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Patient Login Id</th> 
                <th style="padding: 20px; font-size: 15px; text-align: center;">Update</th>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            ?>
            <tr> 

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["slotName"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["doctorName"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["patientName"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["category"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "{$row["slotTime"]}"
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["day"];
            ?>
            </td>
 
            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["date"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["department"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["slotDescription"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["doctorLoginId"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo $row["patientLoginId"];
            ?>
            </td>

            <td style="padding: 20px; font-size: 15px; text-align: center;">
            <?php
            echo "<a class='btn btn-primary' href='book_slot.php?slotId={$row["slotId"]}'>Book</a>";
            ?>
            </td>
            
            
            </tr>
            <?php
            }
            ?>  
        </tbody>          
        </table>
        </div>
        </center>
    </div>
</body>
</html>