<?php
session_start();
require_once "../../PDO/pdo.php";
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'patient') {
    header("location:../../login/login.php"); //redirecting
}
?>

<header class="header">
        <a href="patienthome.php">Patient Dashboard</a>
        <div class="logout">
        <a href="../../login/logout.php" class="btn btn-primary">Logout</a>
        </div>
    </header>

    <aside style="position: relative;">
        <ul>
            <li>
                <a href="patient_details.php">My Details</a>
            </li>
            <li>
                <a href="make_appointment.php">Book Appointment</a>
            </li>
            <li>
                <a href="view_appointment.php">View Appointment</a>
            </li>
            <li>
                <a href="test_reports.php">Reports</a>
            </li>
        </ul>
    </aside>