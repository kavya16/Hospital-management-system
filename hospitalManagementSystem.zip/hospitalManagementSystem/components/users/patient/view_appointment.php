<?php
require_once "../../PDO/pdo.php";
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'patient') {
    header("location:../../login/login.php"); //redirecting
}

$user_id = $_SESSION['loginId'];
$sql = "SELECT * FROM slots WHERE patientLoginId = '$user_id'";
$stmt = $pdo->query($sql);
?>
<?php
include 'calendar.php';
$year = 2022; 
$month = 11;
$i = 0;

while($i < 6) {
	$calendar[$i] = new Calendar(date("$year-$month-1"));
	$month++;
	if($month == 13){
		$year++;
		$month = 1;
	}	
	$i++;
}

while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
$date = $row['date'];
$slotYear = date('Y', strtotime($date));
$slotMonth = date('F', strtotime($date));
$nmonth = date('m',strtotime($slotMonth));
$year = date("Y"); 
$month = date('m');
$current_date = strtotime(date("Y-m-d"));
$end_date = strtotime($date );
$daysDiff = ($end_date - $current_date)/60/60/24;
if($daysDiff < 0) {
	$color = 'red';
}else if($daysDiff == 0) {
	$color = 'yellow';
}else {
	$color = 'green';
}
$slotDesp = $row['slotName'];
$slotDesp .= "  ";
$slotDesp .= $row['slotTime'];
$slotDesp .= "  ";
$slotDesp .= $row['slotDescription'];
// $yearDiff = $slotYear - $year;
// $monthDiff = $slotMonth - $month;
if($slotYear == 2022 && $nmonth == 11) {
	$calendar[0]->add_event("$slotDesp", "$date", 1, $color);
	$calendar[0]->add_event("$slotDesp", "$date", 1, $color);
}else if($slotYear == 2022 && $nmonth == 12) {
	$calendar[1]->add_event("$slotDesp", "$date", 1, $color);
}else if($slotYear == 2023 && $nmonth == 01) {
	$calendar[2]->add_event("$slotDesp", "$date", 1, $color);
}else if($slotYear == 2023 && $nmonth == 02) {
	$calendar[3]->add_event("$slotDesp", "$date", 1, $color);
}else if($slotYear == 2023 && $nmonth == 03) {
	$calendar[4]->add_event("$slotDesp", "$date", 1, $color);
}else if($slotYear == 2023 && $nmonth == 04) {
	$calendar[5]->add_event("$slotDesp", "$date", 1, $color);
}

}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Event Calendar</title>
        <link href="patient.css" rel="stylesheet" type="text/css">
		<link href="style.css" rel="stylesheet" type="text/css">
		<link href="calendar.css" rel="stylesheet" type="text/css">
	</head>
	<body>

    <?php
    include 'patient_sidebar.php';
    ?>
<center>
		<div class="content home" style="margin-top: 20px; margin-left: 450px;">
			<?=$calendar[0]?>
		</div>
</center>
	</body>
</html>