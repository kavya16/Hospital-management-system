<?php
require_once "../../PDO/pdo.php";
$visible = false;
session_start();
if(!isset($_SESSION['username']))
{
    header("location:../../login/login.php"); //redirecting
}elseif($_SESSION['userType'] != 'patient') {
    header("location:../../login/login.php"); //redirecting
}

$user_id = $_SESSION['loginId'];
$sql = "SELECT * FROM patientadmissions WHERE loginId = '$user_id'";
$stmt = $pdo->query($sql);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['Update'])) {
    $firstName = $_POST['firstName'];
    $middleName = $_POST['middleName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $userName = $_POST['userName'];
    $password = $_POST['password'];
    $department = $_POST["department"];
    $doctor = $_POST['doctor']; 
    $textarea = $_POST['textarea'];
    $array = array(); //this checking of username existance can be done using jquery
    $check = "SELECT * FROM patientadmissions WHERE loginId='$user_id'";
    $sqlrows = $pdo->query($check);
    while ($rows = $sqlrows->fetch(PDO::FETCH_ASSOC)) {
        array_push($array, $rows);
    }
    if(count($array) == 1) {
    $sql = "UPDATE `patientadmissions` SET `firstName` = '$firstName', 
    `middleName` = '$middleName', 
    `lastName` = '$lastName', `email` = '$email', `phone` = '$phone', 
    `username` = '$userName', `password` = '$password',
    `departmentName` = '$department', 
    `healthProblem` = '$textarea', `doctor` = '$doctor' 
    WHERE `patientadmissions`.`loginId` = $user_id";
    $stmt = $pdo->query($sql);
    if($stmt) {
        $id = $row['loginId'];
        $sql = "UPDATE `login` SET `userName` = '$userName', 
        `phone` = '$phone', 
        `email` = '$email', `userType` = 'patient', `password` = '$password'
        WHERE loginId = $user_id";
        $finalUpdate = $pdo->query($sql);
        $visible = true;
    }
    }else {
    echo "<script type='text/javascript'>
          alert('Patient doesn't exist. Please create the patient');
          </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" type="text/css" href="patient.css">
    <link rel="stylesheet" type="text/css" href="input.css">
    <?php
    include '../../../bootstrap/bootstrap.php';
    ?>
</head>
<body>


    <?php
    include 'patient_sidebar.php';
    ?>

<center>
    <div class="content">
    <h1>My details</h1>

    <?php
        if($visible) {
        if($finalUpdate){
        echo "<p style='color:green;'>Update Successful</p>";
       //header("location:#");
        }else {
            echo "<p style='color:red;'>Update Failed</p>";
            //header("location:#");
        }
    }
    ?>

    <div class="div_deg">
    <form action="#" method="POST" class="form"> <!--# means the handle code will be in the same file-->

    <div class="add_patient">
    <label class="label_text" for="firstName" style="font-weight: 700;">First Name</label>
    <input  style = "margin: 5px;" class="input_patient" id ="firstName" 
    type="text" name="firstName" value="<?php echo "{$row['firstName']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="middleName" style="font-weight: 700;">Middle Name</label>
    <input  style = "margin: 5px;" class="input_patient" id="middleName" 
    type="text" name="middleName" value="<?php echo "{$row['middleName']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="lastName" style="font-weight: 700;">Last Name</label>
    <input  style = "margin: 5px;" class="input_patient" id="lastName" 
    type="text" name="lastName" value="<?php echo "{$row['lastName']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="email" style="font-weight: 700;">Email</label>
    <input  style = "margin: 5px;" class="input_patient" id="email" 
    type="email" name="email" value="<?php echo "{$row['email']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="phone" style="font-weight: 700;">Phone</label>
    <input  style = "margin: 5px;" class="input_patient" id="phone" 
    type="number" name="phone" value="<?php echo "{$row['phone']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="userName" style="font-weight: 700;">username</label>
    <input  style = "margin: 5px;" class="input_patient" id ="userName" 
    type="text" name="userName" value="<?php echo "{$row['username']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="password" style="font-weight: 700;">password</label>
    <input  style = "margin: 5px;" class="input_patient" id ="password" 
    type="text" name="password" value="<?php echo "{$row['password']}";?>"/>
   </div> 

   <div class="add_patient">
    <label class="label_text" for="doctor" style="font-weight: 700;">Doctor</label>
    <input  style = "margin: 5px;" class="input_patient" id ="doctor" 
    type="text" name="doctor" value="<?php echo "{$row['doctor']}";?>"/>
   </div> 

   <div style="margin-left: -90px; margin-top: 10px;">
   <label for="doctor" style="font-weight: 700;">Doctor </label>
   <select name="doctor" id="doctor" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT firstName, middleName, lastName FROM doctors";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
    $doctorName = $array2[$i]["firstName"] . " " . $array2[$i]["middleName"] . " " . $array2[$i]["lastName"];
    echo "<option value='$doctorName'>$doctorName</option>";
    $i++;
    }
   ?>
    </select>
</div>

   <div style="margin-left: -235px; margin-top: 10px;">
   <label for="department" style="font-weight: 700;">Department </label>
   <select name="department" id="department" style="border-radius: 5px;border: 1px solid blue;">
   <?php
   $array2 = array();
   $sql = "SELECT DepartmentName FROM department";
   $stmt4 = $pdo->query($sql);
   while ($rows = $stmt4->fetch(PDO::FETCH_ASSOC)) {
    array_push($array2, $rows);
   }
    $i = 0;
    while($i < count($array2)) {
        $departmentName = $array2[$i]["DepartmentName"];
        echo "<option value='$departmentName'>$departmentName</option>";
    $i++;
    }
   ?>
    </select>
</div>

   <div class="add_patient">
    <label class="label_text" style="font-weight: 700;">Health Problem</label>
    <textarea class="input_txt" name="textarea"><?php echo "{$row['healthProblem']}";?></textarea>
   </div> 

   <div class="add_patient button">
    <input class="btn btn-primary" id="submit" type="submit" name="Update" value="Update" />
   </div>

</form>
</div>

</center>
</body>
</html>