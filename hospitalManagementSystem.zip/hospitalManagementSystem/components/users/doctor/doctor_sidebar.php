<header class="header">
        <a href="">Doctor Dashboard</a>
        <div class="logout">
        <a href="../../login/logout.php" class="btn btn-primary">Logout</a>
        </div>
    </header>

    <aside>
        <ul>
            <li>
                <a href="add_patient.php">Add Patient</a>
            </li>
            <li>
                <a href="view_patient.php">View Patient</a>
            </li>
            <li>
                <a href="add_appointment.php">Add Appointment</a>
            </li>
            <li>
                <a href="view_appointment.php">View Appointment</a>
            </li>
        </ul>
    </aside>