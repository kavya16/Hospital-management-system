var _gaq = _gaq || [];
let isProductionMode = window && window.serviceTopology && window.serviceTopology.productionMode;
if (isProductionMode) {
  _gaq.push(['_setAccount', 'UA-2117194-1']);
  _gaq.push(['_setDomainName', '.wix.com']);
} else {
  _gaq.push(['_setAccount', 'UA-2117194-2']);
  _gaq.push(['_setDomainName', '.wixpress.com']);
}
_gaq.push(['_trackPageview']);

(function () {
  var ga = document.createElement('script');
  ga.type = 'text/javascript';
  ga.async = true;
  ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(ga, s);
})();
